import { createFileRoute, Link } from '@tanstack/react-router'

export const Route = createFileRoute('/projects')({
  component: ProjectsRedirect,
})

function ProjectsRedirect() {
  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'var(--deep)',
        textAlign: 'center',
        gap: '2rem',
        padding: '2rem',
      }}
    >
      <p
        style={{
          fontFamily: "'Jost', sans-serif",
          fontSize: '0.65rem',
          letterSpacing: '0.35em',
          textTransform: 'uppercase',
          color: 'var(--gold)',
        }}
      >
        Proyectos
      </p>
      <h1
        style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontSize: 'clamp(2.5rem, 6vw, 4rem)',
          fontWeight: 300,
          color: 'var(--cream)',
          lineHeight: 1.1,
          margin: 0,
        }}
      >
        Todos los proyectos<br />
        <em style={{ fontStyle: 'italic', color: 'var(--gold-pale)' }}>viven en casa</em>
      </h1>
      <Link
        to="/"
        style={{
          fontFamily: "'Jost', sans-serif",
          fontSize: '0.7rem',
          fontWeight: 500,
          letterSpacing: '0.25em',
          textTransform: 'uppercase',
          color: 'var(--deep)',
          background: 'var(--gold)',
          padding: '1rem 2.5rem',
          textDecoration: 'none',
          display: 'inline-block',
          marginTop: '1rem',
        }}
      >
        Ver portfolio →
      </Link>
    </div>
  )
}
