import { createFileRoute, Link } from '@tanstack/react-router'
import { allBlogs } from 'content-collections'
import { marked } from 'marked'

export const Route = createFileRoute('/blog/$slug')({
  component: BlogPost,
})

function BlogPost() {
  const { slug } = Route.useParams()
  const post = allBlogs.find((p) => p._meta.path === slug)

  if (!post) {
    return (
      <div
        style={{
          minHeight: '100vh',
          background: 'var(--deep)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'column',
          gap: '1.5rem',
          padding: '2rem',
        }}
      >
        <h1
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: '2rem',
            fontWeight: 300,
            color: 'var(--cream)',
          }}
        >
          Artículo no encontrado
        </h1>
        <Link
          to="/"
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '0.7rem',
            letterSpacing: '0.2em',
            textTransform: 'uppercase',
            color: 'var(--gold)',
            textDecoration: 'none',
          }}
        >
          ← Volver al inicio
        </Link>
      </div>
    )
  }

  const html = marked(post.content)

  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'var(--deep)',
        padding: '7rem 2rem 6rem',
      }}
    >
      <div style={{ maxWidth: '720px', margin: '0 auto' }}>
        <Link
          to="/"
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '0.65rem',
            letterSpacing: '0.25em',
            textTransform: 'uppercase',
            color: 'var(--cream-muted)',
            textDecoration: 'none',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            marginBottom: '4rem',
          }}
        >
          ← Volver
        </Link>

        <article>
          <header style={{ marginBottom: '4rem' }}>
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: '0.5rem',
                marginBottom: '1.5rem',
              }}
            >
              {post.tags.map((tag) => (
                <span
                  key={tag}
                  style={{
                    fontFamily: "'Jost', sans-serif",
                    fontSize: '0.6rem',
                    fontWeight: 500,
                    letterSpacing: '0.2em',
                    textTransform: 'uppercase',
                    color: 'var(--teal-light)',
                    border: '1px solid rgba(30, 143, 163, 0.3)',
                    padding: '0.25rem 0.7rem',
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>

            <h1
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: 'clamp(2rem, 5vw, 3.5rem)',
                fontWeight: 400,
                color: 'var(--cream)',
                lineHeight: 1.15,
                marginBottom: '1.5rem',
              }}
            >
              {post.title}
            </h1>

            <p
              style={{
                fontFamily: "'Jost', sans-serif",
                fontSize: '0.75rem',
                color: 'var(--cream-muted)',
                letterSpacing: '0.1em',
              }}
            >
              {new Date(post.date).toLocaleDateString('es-ES', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}{' '}
              · {post.author}
            </p>
          </header>

          <div
            style={{
              fontFamily: "'Jost', sans-serif",
              fontSize: '1rem',
              fontWeight: 300,
              color: 'var(--cream-dim)',
              lineHeight: 1.9,
            }}
            dangerouslySetInnerHTML={{ __html: html as string }}
          />
        </article>
      </div>
    </div>
  )
}
