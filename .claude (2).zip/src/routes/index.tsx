import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useRef, useState } from 'react'

export const Route = createFileRoute('/')({
  component: Portfolio,
})

// ─── Lighthouse Beam ───────────────────────────────────────────────
function LighthouseBeam() {
  return (
    <div className="beam-wrapper" aria-hidden="true">
      <div className="beam-primary" />
      <div className="beam-secondary" />
    </div>
  )
}

// ─── Noise Overlay ─────────────────────────────────────────────────
function NoiseOverlay() {
  return <div className="noise-overlay" aria-hidden="true" />
}

// ─── Particle Field (canvas) ────────────────────────────────────────
function ParticleField() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener('resize', resize)

    type Particle = {
      x: number; y: number; size: number; opacity: number
      speed: number; dir: number; drift: number; driftSpeed: number
    }

    const particles: Particle[] = Array.from({ length: 90 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      size: Math.random() * 1.2 + 0.3,
      opacity: Math.random() * 0.35 + 0.05,
      speed: Math.random() * 0.18 + 0.04,
      dir: Math.random() * Math.PI * 2,
      drift: Math.random() * Math.PI * 2,
      driftSpeed: (Math.random() - 0.5) * 0.008,
    }))

    let animId: number

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      for (const p of particles) {
        p.drift += p.driftSpeed
        p.x += Math.cos(p.dir + p.drift * 0.4) * p.speed
        p.y += Math.sin(p.dir + p.drift * 0.4) * p.speed * 0.6

        if (p.x < 0) p.x = canvas.width
        if (p.x > canvas.width) p.x = 0
        if (p.y < 0) p.y = canvas.height
        if (p.y > canvas.height) p.y = 0

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(196, 154, 60, ${p.opacity})`
        ctx.fill()
      }

      animId = requestAnimationFrame(animate)
    }

    animate()
    return () => {
      cancelAnimationFrame(animId)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: 'absolute',
        inset: 0,
        pointerEvents: 'none',
        zIndex: 1,
        opacity: 0.7,
        mixBlendMode: 'screen',
      }}
      aria-hidden="true"
    />
  )
}

// ─── Navigation ─────────────────────────────────────────────────────
function Nav() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', handler, { passive: true })
    return () => window.removeEventListener('scroll', handler)
  }, [])

  const links = [
    { href: '#manifesto', label: 'Filosofía' },
    { href: '#about', label: 'Sobre mí' },
    { href: '#projects', label: 'Proyectos' },
    { href: '#contact', label: 'Contacto' },
  ]

  return (
    <nav className={`mar-nav ${scrolled ? 'scrolled' : ''}`}>
      <a href="#hero" className="nav-logo" aria-label="ITXASO — inicio">
        ITXASO
      </a>
      <ul className="nav-links">
        {links.map((l) => (
          <li key={l.href}>
            <a href={l.href}>{l.label}</a>
          </li>
        ))}
      </ul>
      <button
        className="nav-mobile-toggle"
        aria-label="Abrir menú"
        onClick={() => setMobileOpen(!mobileOpen)}
      >
        <span style={{ transform: mobileOpen ? 'rotate(45deg) translate(4px, 4px)' : '' }} />
        <span style={{ opacity: mobileOpen ? 0 : 1 }} />
        <span style={{ transform: mobileOpen ? 'rotate(-45deg) translate(4px, -4px)' : '' }} />
      </button>

      {mobileOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            top: 0,
            background: 'rgba(6, 16, 29, 0.97)',
            zIndex: 49,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '2.5rem',
          }}
        >
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setMobileOpen(false)}
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: '2.5rem',
                fontWeight: 300,
                color: 'var(--cream)',
                textDecoration: 'none',
                letterSpacing: '0.05em',
              }}
            >
              {l.label}
            </a>
          ))}
          <button
            onClick={() => setMobileOpen(false)}
            style={{
              position: 'fixed',
              top: '1.8rem',
              right: '2rem',
              background: 'none',
              border: 'none',
              color: 'var(--cream-dim)',
              fontSize: '1.5rem',
              cursor: 'pointer',
              fontFamily: "'Jost', sans-serif",
              fontWeight: 300,
            }}
            aria-label="Cerrar menú"
          >
            ✕
          </button>
        </div>
      )}
    </nav>
  )
}

// ─── Hero Section ────────────────────────────────────────────────────
function HeroSection() {
  return (
    <section id="hero" className="hero-section">
      <ParticleField />
      <div style={{ position: 'relative', zIndex: 4, textAlign: 'center' }}>
        <p className="hero-eyebrow">Content Creator · Digital Strategist</p>
        <h1 className="hero-name">
          <span className="name-accent">M</span>AR
        </h1>
        <p className="hero-subtitle">donde la estrategia ilumina el mensaje</p>
        <div className="hero-divider" />
        <p className="hero-tagline">Creatividad · Propósito · Impacto real</p>
      </div>

      <div className="scroll-indicator" aria-hidden="true">
        <span>desplazar</span>
        <div className="scroll-line" />
      </div>
    </section>
  )
}

// ─── Manifesto Section ───────────────────────────────────────────────
function ManifestoSection() {
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect() } },
      { threshold: 0.15 },
    )
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  return (
    <section id="manifesto" className="manifesto-section">
      <div className="manifesto-bg-text" aria-hidden="true">ITXASO</div>
      <div
        ref={ref}
        className="manifesto-inner"
        style={{
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(40px)',
          transition: 'opacity 1.1s ease, transform 1.1s ease',
        }}
      >
        <p className="manifesto-label">Filosofía</p>
        <p className="manifesto-text">
          <span className="dim">Cuando la</span>{' '}
          <span className="highlight">estrategia digital</span>{' '}
          <span className="dim">se encuentra con el</span>{' '}
          <span className="highlight">contenido creativo</span>
          <span className="dim">,</span>{' '}
          <span className="dim">el resultado es una comunicación más efectiva, capaz de</span>{' '}
          <span className="highlight">conectar en niveles más profundos</span>
          <span className="dim">, inspirar y generar</span>{' '}
          <span className="highlight">impacto real</span>
          <span className="dim">.</span>
        </p>
        <div className="manifesto-accent">
          El compromiso con un planeta más ético no es solo un valor personal —
          es el principio que guía cada proyecto. El alineamiento entre propósito y profesión
          es la clave para generar un impacto verdaderamente significativo.
        </div>
      </div>
    </section>
  )
}

// ─── About Section ───────────────────────────────────────────────────
function AboutSection() {
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect() } },
      { threshold: 0.1 },
    )
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  return (
    <section id="about" className="about-section">
      <div
        ref={ref}
        className="about-grid"
        style={{
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(50px)',
          transition: 'opacity 1.2s ease, transform 1.2s ease',
        }}
      >
        {/* Visual */}
        <div className="about-visual">
          <div className="about-depth-visual">
            <div className="depth-layer" />
            <div className="depth-ring" />
            <div className="depth-ring" />
            <div className="depth-ring" />
            <div className="depth-center" />
            <div
              style={{
                position: 'absolute',
                top: '20%',
                left: '15%',
                width: '6px',
                height: '6px',
                background: 'rgba(196, 154, 60, 0.4)',
                borderRadius: '50%',
                animation: 'glow 4s ease-in-out infinite 1s',
              }}
            />
            <div
              style={{
                position: 'absolute',
                top: '65%',
                right: '20%',
                width: '4px',
                height: '4px',
                background: 'rgba(30, 143, 163, 0.5)',
                borderRadius: '50%',
                animation: 'glow 5s ease-in-out infinite 2s',
              }}
            />
            <div
              style={{
                position: 'absolute',
                bottom: '25%',
                left: '25%',
                width: '3px',
                height: '3px',
                background: 'rgba(196, 154, 60, 0.3)',
                borderRadius: '50%',
                animation: 'glow 3.5s ease-in-out infinite 0.5s',
              }}
            />
          </div>
          <div className="about-number" aria-hidden="true">ITXASO</div>
        </div>

        {/* Content */}
        <div className="about-content">
          <p className="about-label">Sobre mí</p>
          <h2 className="about-heading">
            Una voz al servicio<br />
            <em style={{ fontStyle: 'italic', color: 'var(--gold-pale)' }}>
              de lo que importa
            </em>
          </h2>
          <p className="about-body">
            Mi experiencia nació en la gestión de comunidades digitales dentro de una
            asociación comprometida con valores esenciales — aprendiendo que la comunicación
            auténtica construye mundos.
          </p>
          <p className="about-body">
            Hoy colaboro con marcas y organizaciones que comparten la visión de un mundo más
            consciente, usando la creatividad y la estrategia digital para transmitir mensajes
            que inspiran, transforman y conectan.
          </p>
          <div className="about-now">
            <p className="about-now-label">Ahora</p>
            <p className="about-now-text">
              "Siempre en búsqueda de nuevos retos que generen un cambio real y duradero.
              La profundidad del océano me recuerda que hay siempre más por descubrir."
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Projects Data ───────────────────────────────────────────────────
const PROJECTS = [
  {
    id: '01',
    title: 'Marea Consciente',
    category: 'Campaña Social · Sostenibilidad',
    desc: 'Estrategia de contenido digital para una marca de moda eco-consciente. Crecimiento de comunidad del 340% en seis meses a través de narrativa auténtica y activaciones de impacto.',
    tags: ['Estrategia Social', 'Content Creation', 'Sostenibilidad'],
    variant: 'featured',
    bg: 'teal',
  },
  {
    id: '02',
    title: 'Horizontes Digitales',
    category: 'Community Building',
    desc: 'Construcción y activación de comunidad digital para una ONG medioambiental. Gestión de contenido, moderación y estrategia de engagement.',
    tags: ['Community', 'ONG', 'Digital Strategy'],
    variant: 'tall',
    bg: 'navy',
  },
  {
    id: '03',
    title: 'Faro Editorial',
    category: 'Contenido · Editorial',
    desc: 'Serie de contenido editorial para una plataforma de economía circular. Copywriting, curaduría visual y planificación de publicaciones.',
    tags: ['Editorial', 'Copywriting', 'Circular Economy'],
    variant: 'short',
    bg: 'deep',
  },
  {
    id: '04',
    title: 'Corrientes Vivas',
    category: 'Newsletter · Comunidad',
    desc: 'Newsletter mensual sobre consumo consciente y cultura digital. Escritura, diseño de contenidos y gestión de lista de suscriptores.',
    tags: ['Newsletter', 'Conscious Living', 'Writing'],
    variant: 'short',
    bg: 'teal',
  },
]

function ProjectCard({ project, delay }: { project: typeof PROJECTS[0]; delay: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect() } },
      { threshold: 0.05 },
    )
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  const cardClass = [
    'project-card',
    project.variant === 'featured' ? 'project-card--featured' : '',
    project.variant === 'tall' ? 'project-card--tall' : '',
    project.variant === 'short' ? 'project-card--short' : '',
  ].filter(Boolean).join(' ')

  return (
    <div
      ref={ref}
      className={cardClass}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(30px)',
        transition: `opacity 0.9s ease ${delay}ms, transform 0.9s ease ${delay}ms`,
      }}
    >
      <div className={`project-bg-visual project-bg-visual--${project.bg}`} aria-hidden="true" />
      <div className="project-shimmer" aria-hidden="true" />
      <div className="project-inner">
        <span className="project-number" aria-hidden="true">{project.id}</span>
        <div>
          <p className="project-category">{project.category}</p>
          <h3 className="project-title">{project.title}</h3>
          <p className="project-desc">{project.desc}</p>
          <div className="project-tags">
            {project.tags.map((t) => (
              <span key={t} className="project-tag">{t}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function ProjectsSection() {
  return (
    <section id="projects" className="projects-section">
      <div className="section-header">
        <div>
          <p className="section-label">Trabajo</p>
          <h2 className="section-title">Proyectos</h2>
        </div>
        <p
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontStyle: 'italic',
            color: 'var(--cream-muted)',
            fontSize: '1rem',
            maxWidth: '28ch',
            textAlign: 'right',
            lineHeight: 1.5,
          }}
        >
          Cada proyecto es una marea<br />que deja huella.
        </p>
      </div>

      <div className="projects-grid">
        {PROJECTS.map((p, i) => (
          <ProjectCard key={p.id} project={p} delay={i * 120} />
        ))}
      </div>
    </section>
  )
}

// ─── Contact Section ─────────────────────────────────────────────────
function ContactSection() {
  const [submitted, setSubmitted] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect() } },
      { threshold: 0.1 },
    )
    if (ref.current) obs.observe(ref.current)
    return () => obs.disconnect()
  }, [])

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    fetch('/contact.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(formData as unknown as Record<string, string>).toString(),
    })
      .then(() => setSubmitted(true))
      .catch(() => setSubmitted(true))
  }

  return (
    <section id="contact" className="contact-section">
      <div
        ref={ref}
        className="contact-inner"
        style={{
          opacity: visible ? 1 : 0,
          transform: visible ? 'translateY(0)' : 'translateY(40px)',
          transition: 'opacity 1.1s ease, transform 1.1s ease',
        }}
      >
        <p
          style={{
            fontSize: '0.65rem',
            fontWeight: 500,
            letterSpacing: '0.35em',
            textTransform: 'uppercase',
            color: 'var(--gold)',
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            marginBottom: '2.5rem',
          }}
        >
          <span
            style={{
              display: 'inline-block',
              width: '40px',
              height: '1px',
              background: 'var(--gold)',
            }}
          />
          Contacto
        </p>

        <h2 className="contact-heading">
          Hagamos algo<br />
          <em>que valga la pena</em>
        </h2>

        <p className="contact-subtext">
          Si tu proyecto busca conectar con autenticidad, generar impacto real y alinearse con
          un propósito mayor — me encantaría escucharte.
        </p>

        {submitted ? (
          <div className="success-message">
            <div className="success-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </div>
            <p className="success-title">Mensaje recibido.</p>
            <p className="success-text">
              Gracias por escribir. Me pondré en contacto contigo pronto —
              como la marea, siempre vuelvo.
            </p>
          </div>
        ) : (
          <form
            name="contact"
            method="POST"
            data-netlify="true"
            netlify-honeypot="bot-field"
            onSubmit={handleSubmit}
            className="contact-form"
          >
            <input type="hidden" name="form-name" value="contact" />
            <p hidden>
              <label>
                No rellenar: <input name="bot-field" />
              </label>
            </p>

            <div className="form-group">
              <label htmlFor="name" className="form-label">Nombre</label>
              <input
                id="name"
                name="name"
                type="text"
                required
                placeholder="Tu nombre"
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label htmlFor="email" className="form-label">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                required
                placeholder="tu@email.com"
                className="form-input"
              />
            </div>

            <div className="form-group">
              <label htmlFor="message" className="form-label">Mensaje</label>
              <textarea
                id="message"
                name="message"
                required
                placeholder="Cuéntame sobre tu proyecto, tu visión, tu mundo..."
                className="form-textarea"
              />
            </div>

            <button type="submit" className="form-submit" data-hover>
              Enviar mensaje
            </button>
          </form>
        )}
      </div>
    </section>
  )
}

// ─── Footer ──────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="mar-footer">
      <div className="footer-beam" aria-hidden="true" />
      <div className="footer-logo" aria-hidden="true">ITXASO</div>
      <p className="footer-tagline">Iluminando el camino, una historia a la vez.</p>
      <p className="footer-copy">
        © {new Date().getFullYear()} Itxaso
      </p>
    </footer>
  )
}

// ─── Portfolio Root ───────────────────────────────────────────────────
function Portfolio() {
  return (
    <>
      <LighthouseBeam />
      <NoiseOverlay />
      <Nav />
      <main>
        <HeroSection />
        <ManifestoSection />
        <AboutSection />
        <ProjectsSection />
        <ContactSection />
      </main>
      <Footer />
    </>
  )
}
