import { createFileRoute, Link } from '@tanstack/react-router'
import { useState } from 'react'

export const Route = createFileRoute('/contact')({
  component: ContactPage,
})

function ContactPage() {
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const formData = new FormData(form)
    fetch('/contact.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(formData as unknown as Record<string, string>).toString(),
    })
      .then(() => setSubmitted(true))
      .catch(() => setSubmitted(true))
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'linear-gradient(180deg, var(--deep) 0%, #050e1a 100%)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '6rem 2rem',
      }}
    >
      <div style={{ maxWidth: '600px', width: '100%' }}>
        <Link
          to="/"
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '0.65rem',
            letterSpacing: '0.25em',
            textTransform: 'uppercase',
            color: 'var(--cream-muted)',
            textDecoration: 'none',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            marginBottom: '3rem',
          }}
        >
          ← Volver
        </Link>

        <h1
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: 'clamp(2.5rem, 5vw, 4rem)',
            fontWeight: 300,
            color: 'var(--cream)',
            lineHeight: 1.1,
            marginBottom: '1.5rem',
          }}
        >
          Hagamos algo<br />
          <em style={{ fontStyle: 'italic', color: 'var(--gold-pale)' }}>que valga la pena</em>
        </h1>
        <p
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '0.95rem',
            fontWeight: 300,
            color: 'var(--cream-dim)',
            lineHeight: 1.8,
            marginBottom: '3rem',
          }}
        >
          Si tu proyecto busca conectar con autenticidad y generar impacto real,
          me encantaría escucharte.
        </p>

        {submitted ? (
          <div className="success-message">
            <div className="success-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            </div>
            <p className="success-title">Mensaje recibido.</p>
            <p className="success-text">
              Gracias por escribir. Me pondré en contacto contigo pronto.
            </p>
          </div>
        ) : (
          <form
            name="contact"
            method="POST"
            data-netlify="true"
            netlify-honeypot="bot-field"
            onSubmit={handleSubmit}
            className="contact-form"
          >
            <input type="hidden" name="form-name" value="contact" />
            <p hidden><label>No rellenar: <input name="bot-field" /></label></p>

            <div className="form-group">
              <label htmlFor="name" className="form-label">Nombre</label>
              <input id="name" name="name" type="text" required placeholder="Tu nombre" className="form-input" />
            </div>
            <div className="form-group">
              <label htmlFor="email" className="form-label">Email</label>
              <input id="email" name="email" type="email" required placeholder="tu@email.com" className="form-input" />
            </div>
            <div className="form-group">
              <label htmlFor="message" className="form-label">Mensaje</label>
              <textarea id="message" name="message" required placeholder="Cuéntame sobre tu proyecto..." className="form-textarea" />
            </div>
            <button type="submit" className="form-submit" data-hover>
              Enviar mensaje
            </button>
          </form>
        )}
      </div>
    </div>
  )
}
