import { createFileRoute, Link } from '@tanstack/react-router'
import { allJobs, allEducations } from 'content-collections'

export const Route = createFileRoute('/resume')({
  component: Resume,
})

function Resume() {
  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'var(--deep)',
        padding: '8rem 2rem 6rem',
      }}
    >
      <div style={{ maxWidth: '760px', margin: '0 auto' }}>
        <Link
          to="/"
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '0.65rem',
            letterSpacing: '0.25em',
            textTransform: 'uppercase',
            color: 'var(--cream-muted)',
            textDecoration: 'none',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            marginBottom: '4rem',
          }}
        >
          ← Volver
        </Link>

        <p
          style={{
            fontFamily: "'Jost', sans-serif",
            fontSize: '0.65rem',
            letterSpacing: '0.35em',
            textTransform: 'uppercase',
            color: 'var(--gold)',
            marginBottom: '1rem',
          }}
        >
          Experiencia
        </p>
        <h1
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: 'clamp(2.5rem, 5vw, 4rem)',
            fontWeight: 300,
            color: 'var(--cream)',
            marginBottom: '5rem',
            lineHeight: 1.1,
          }}
        >
          Trayectoria
        </h1>

        <section style={{ marginBottom: '5rem' }}>
          <h2
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: '1.8rem',
              fontWeight: 400,
              color: 'var(--cream)',
              borderBottom: '1px solid rgba(196, 154, 60, 0.2)',
              paddingBottom: '1rem',
              marginBottom: '3rem',
            }}
          >
            Experiencia profesional
          </h2>
          {allJobs.map((job) => (
            <div
              key={job.jobTitle}
              style={{
                marginBottom: '3rem',
                paddingLeft: '1.5rem',
                borderLeft: '2px solid rgba(196, 154, 60, 0.25)',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  flexWrap: 'wrap',
                  gap: '0.5rem',
                  marginBottom: '0.5rem',
                }}
              >
                <div>
                  <h3
                    style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: '1.4rem',
                      fontWeight: 500,
                      color: 'var(--cream)',
                      margin: 0,
                    }}
                  >
                    {job.jobTitle}
                  </h3>
                  <p
                    style={{
                      fontFamily: "'Jost', sans-serif",
                      fontSize: '0.85rem',
                      color: 'var(--teal-light)',
                      margin: '0.25rem 0 0',
                    }}
                  >
                    {job.company} · {job.location}
                  </p>
                </div>
                <span
                  style={{
                    fontFamily: "'Jost', sans-serif",
                    fontSize: '0.65rem',
                    letterSpacing: '0.15em',
                    color: 'var(--gold)',
                    border: '1px solid rgba(196, 154, 60, 0.3)',
                    padding: '0.25rem 0.75rem',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {job.startDate} — {job.endDate ?? 'Presente'}
                </span>
              </div>
              <p
                style={{
                  fontFamily: "'Jost', sans-serif",
                  fontSize: '0.9rem',
                  fontWeight: 300,
                  color: 'var(--cream-dim)',
                  lineHeight: 1.8,
                  margin: '1rem 0',
                }}
              >
                {job.summary}
              </p>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {job.tags.map((tag) => (
                  <span
                    key={tag}
                    style={{
                      fontFamily: "'Jost', sans-serif",
                      fontSize: '0.6rem',
                      fontWeight: 500,
                      letterSpacing: '0.15em',
                      textTransform: 'uppercase',
                      color: 'rgba(196, 154, 60, 0.7)',
                      border: '1px solid rgba(196, 154, 60, 0.2)',
                      padding: '0.25rem 0.6rem',
                    }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </section>

        <section>
          <h2
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: '1.8rem',
              fontWeight: 400,
              color: 'var(--cream)',
              borderBottom: '1px solid rgba(196, 154, 60, 0.2)',
              paddingBottom: '1rem',
              marginBottom: '3rem',
            }}
          >
            Formación
          </h2>
          {allEducations.map((edu) => (
            <div
              key={edu.school}
              style={{
                marginBottom: '2.5rem',
                paddingLeft: '1.5rem',
                borderLeft: '2px solid rgba(30, 143, 163, 0.25)',
              }}
            >
              <h3
                style={{
                  fontFamily: "'Cormorant Garamond', serif",
                  fontSize: '1.4rem',
                  fontWeight: 500,
                  color: 'var(--cream)',
                  margin: 0,
                }}
              >
                {edu.school}
              </h3>
              <p
                style={{
                  fontFamily: "'Jost', sans-serif",
                  fontSize: '0.9rem',
                  fontWeight: 300,
                  color: 'var(--cream-dim)',
                  lineHeight: 1.8,
                  margin: '1rem 0 0',
                }}
              >
                {edu.summary}
              </p>
            </div>
          ))}
        </section>
      </div>
    </div>
  )
}
